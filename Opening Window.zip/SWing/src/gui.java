import java.awt.*;
import java.awt.event.*;
import java.net.*;

import javax.swing.*;
import javax.swing.event.*;

public class gui 
{

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() {
			public void run() 
			{
				try 
				{
					gui window = new gui();
					window.frame.setVisible(true);
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public gui() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() 
	{
		init_frame1();
	}

	public void init_frame1()
	{
		JButton B_token = new JButton();;
		/**
		 * Init Frame
		 */
		JFrame f = new JFrame("The Rising Curve");
		f.getContentPane().setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
		f.setSize(500 , 500);
		f.getContentPane().setLayout(null);
		f.setVisible(true);
		
		/**
		 * Show IP
		 */	
		JTextPane L_IP = new JTextPane();
		L_IP.setFont(new Font("Times New Roman", Font.PLAIN, 31));
		L_IP.setBackground(Color.GRAY);
		L_IP.setForeground(Color.WHITE);
		L_IP.setEditable(false);
		L_IP.setBounds(194, 125, 90, 51);
		f.getContentPane().add(L_IP);
		
		/**
		 * Name
		 */	
		JLabel L_name = new JLabel("The Rising Curve");
		L_name.setFont(new Font("Algerian", Font.PLAIN, 35));
		L_name.setBounds(98, 13, 304, 40);
		f.getContentPane().add(L_name);
		
		/******************************/
		
		/**
		 * Wait message
		 */	
		JTextArea text_msg = new JTextArea();
		text_msg.setFont(new Font("Times New Roman", Font.PLAIN, 21));
		text_msg.setEditable(false);
		text_msg.setBackground(Color.LIGHT_GRAY);
		text_msg.setBounds(141, 322, 200, 28);
		f.getContentPane().add(text_msg);
		
		/******************************/
		/**
		 * Connect
		 */
		JButton B_connect = new JButton("CONNECT");
		
		B_connect.addActionListener(new ActionListener() 
		{
			
			public void actionPerformed(ActionEvent arg0) 
			{
					
				try
				{
					B_token.setEnabled(false);
					ServerSocket s = new ServerSocket(8003);				
					Socket inc = s.accept();
					text_msg.setText("Connection Established");
					inc.close();
					s.close();
				}
				catch (Exception e1)
				{
					JOptionPane.showMessageDialog(f, "ERROR");
				}
			}
		});
		B_connect.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
		B_connect.setBounds(169, 363, 146, 50);
		f.getContentPane().add(B_connect);
		
		
		/**
		 * Generate IP button
		 */
		
		B_token.setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
		B_connect.setEnabled(false);
		B_token.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				try	
				{
					InetAddress local = InetAddress.getLocalHost();
					L_IP.setText(local.getHostAddress());
					String token = new String();
					token = local.getHostAddress().toString();
					L_IP.setText(token.substring(8, 11));
					B_connect.setEnabled(true);
				}
				catch (Exception e)
				{
					JOptionPane.showMessageDialog(f, "IP unavilable");
				}
			}
		});
		B_token.setBounds(145 , 201 , 196 , 40);
		B_token.setText("Generate Token for session");
		f.getContentPane().add(B_token);
		
		
		/******************************/
		
		
		
		
		
		/*****************************/
		
		
	}
}
