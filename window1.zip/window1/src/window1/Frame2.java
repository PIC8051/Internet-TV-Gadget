package window1;
import java.awt.*;

import javax.swing.*;

import java.net.*;
import java.awt.event.*;

class win2
{
	win2(JFrame f)
	{
		JFrame f1 = new JFrame("The Rising Curve");
		f1.getContentPane().setFont(new Font("Microsoft YaHei", Font.PLAIN, 12));
		f1.setSize(500 , 500);
		f1.setLocation(f.getLocation());
		f1.getContentPane().setLayout(null);
		f1.setVisible(true);
				
		/**
		 * Name
		 */	
		JLabel L_name = new JLabel("The Rising Curve");
		L_name.setFont(new Font("Algerian", Font.PLAIN, 35));
		L_name.setBounds(98, 13, 304, 40);
		f1.getContentPane().add(L_name);
		f1.getContentPane().add(L_name);
				
		/**
		 * Connect to default browser
		 */
		JButton b_browser = new JButton("Connect to browser");
		b_browser.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
						
						
				try
				{
					URI u = new URI("https:/www.google.com");
					URL u1 = u.toURL();				
					Desktop d = Desktop.getDesktop();
					d.browse(u);
				}
				catch (Exception e)
				{
					JOptionPane.showMessageDialog(f1, "Invalid URL");
				}
			}
		});
		b_browser.setBounds(134, 227, 216, 47);
		f1.getContentPane().add(b_browser);
		
	}
}

public class Frame2
{
	public Frame2(JFrame f)
	{
		new win2(f);
	}
}